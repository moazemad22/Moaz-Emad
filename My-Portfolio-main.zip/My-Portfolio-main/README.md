# Portfolio

## What is Portfolio?
A personal website to display my CV in an attractive way.

## 🚀 About Me
I'm a Frontend web developer...

  
## 🕵️‍ Skills
Javascript, HTML, CSS, Bootstrap ...

## Desciption
A personal website to display my CV in an attractive way.

## 🔗 Links

- [![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/mohamed-ahmed-bb358b239/)
- [![link](https://img.shields.io/badge/link-green?style=for-the-badge&logo=link&logoColor=black)](https://portfolioo-1.netlify.app)
